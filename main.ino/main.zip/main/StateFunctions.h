#ifndef STATEFUNCTIONS_H
#define STATEFUNCTIONS_H

void pickUp();
void ramp();
void dropOff();

#endif
#include "Arduino.h"
#include "helper.h"
#include <QTRSensors.h>


extern QTRSensors qtr;
extern const uint8_t SensorCount;
extern int sensorValues;
extern const int32_t offsetVal;
extern const int32_t normVal;
extern int32_t s;


extern int FLpin1;
extern int FLpin2;
extern int FLpinEN;

extern int FRpin1;
extern int FRpin2;
extern int FRpinEN;

extern int BLpin1;
extern int BLpin2;
extern int BLpinEN;

extern int BRpin1;
extern int BRpin2;
extern int BRpinEN;


// speed vars, pid
extern const float Nspeed;
extern const float Kp;
extern const float Ki;
extern const float Kd;
extern float P;
extern float I;
extern float D;
extern float pid;

extern int error;
extern int prevError;
extern int speedLeft;
extern int speedRight;

// min and max power output
extern int up_threshold;
extern int low_threshold;

// switching to reverse
extern int Lpin1;
extern int Lpin2;
extern int Rpin1;
extern int Rpin2;

void initializeAll(){
  // configure the sensors
  qtr.setTypeAnalog();
  qtr.setSensorPins((const uint8_t[]){A8, A9, A10, A11, A12, A13, A14, A15}, SensorCount);
  qtr.setEmitterPin(2);

  
  pinMode(FLpin1, OUTPUT);
  pinMode(FLpin2, OUTPUT);
  pinMode(FLpinEN, OUTPUT);

  
  pinMode(FRpin1, OUTPUT);
  pinMode(FRpin2, OUTPUT);
  pinMode(FRpinEN, OUTPUT);

  pinMode(BLpin1, OUTPUT);
  pinMode(BLpin2, OUTPUT);
  pinMode(BLpinEN, OUTPUT);
  
  pinMode(BRpin1, OUTPUT);
  pinMode(BRpin2, OUTPUT);
  pinMode(BRpinEN, OUTPUT);


  digitalWrite(FLpin1, Lpin1);
  digitalWrite(FLpin2, Lpin2);
  
  digitalWrite(FRpin1, Rpin1);
  digitalWrite(FRpin2, Rpin2);

  digitalWrite(BLpin1, Lpin1);
  digitalWrite(BLpin2, Lpin2);
  
  digitalWrite(BRpin1, Rpin1);
  digitalWrite(BRpin2, Rpin2);
}

void lineFollowing() {
  // read raw sensor values
    getError();
    pid = (Kp * P) - (Ki * I) + (Kd * D);
    speedLeft = Nspeed - pid;
    speedRight = Nspeed + pid;
    if (speedLeft > up_threshold){speedLeft = up_threshold;}
    if (speedLeft < low_threshold){ speedLeft = low_threshold;}
    if (speedRight > up_threshold){ speedRight = up_threshold;}
    if (speedRight < low_threshold){ speedRight = low_threshold;}
    Serial.print('\t');
    Serial.print(pid);
    Serial.print('\t');
    Serial.print(speedLeft);
    Serial.print('\t');
    Serial.print(speedRight);
    Serial.println();

    if(speedLeft < 0)
    {
      Lpin1 = 0;
      Lpin2 = 1;
    } else if(speedLeft >= 0)
    {
      Lpin1 = 1;
      Lpin2 = 0;
    }
    if(speedRight < 0)
    {
      Rpin1 = 0;
      Rpin2 = 1;
    } else if(speedRight >= 0)
    {
      Rpin1 = 1;
      Rpin2 = 0;
    }

    digitalWrite(FLpin1, Lpin1);
    digitalWrite(FLpin2, Lpin2);
  
    digitalWrite(FRpin1, Rpin1);
    digitalWrite(FRpin2, Rpin2);

    digitalWrite(BLpin1, Lpin1);
    digitalWrite(BLpin2, Lpin2);
  
    digitalWrite(BRpin1, Rpin1);
    digitalWrite(BRpin2, Rpin2);

    analogWrite(BRpinEN, abs(speedRight));
    analogWrite(FLpinEN, abs(speedLeft));
    analogWrite(BLpinEN, abs(speedLeft));
    analogWrite(FRpinEN, abs(speedRight));
}

// error function
void getError() {
   qtr.read(sensorValues);
   for (uint8_t i = 0; i < SensorCount; i++)
  {
    s[i] = (sensorValues[i]-offsetVal[i])*1000/normVal[i];
    if(s[i] < 0)
    {
      s[i] = 0; 
    }
  }
  error = 8*s[0]+4*s[1]+2*s[2]+s[3]-s[4]-2*s[5]-4*s[6]-8*s[7];

  
  P = error;
  I = I + error;
  D = error-prevError;
  Serial.print('\t');
  Serial.print(error);
  prevError = error;
}

// grab item
void clawSequence(){
  Serial.println("claw sequence");
}

void turnRight90(){
  Serial.println("turn sequence");
}

void turnLeft90(){
  Serial.println("turn sequence");
}


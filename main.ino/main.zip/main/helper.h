#ifndef HELPER_H
#define HELPER_H

void initializeAll();
void lineFollowing();
void getError();
void clawSequence();
void turnRight90();
void turnLeft90();

#endif